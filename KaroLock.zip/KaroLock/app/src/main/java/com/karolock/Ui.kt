package com.karolock

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.widget.*

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.col() = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setBackgroundColor(Color.BLACK)
    setPadding(dp(24), dp(48), dp(24), dp(24))
    gravity = Gravity.CENTER_HORIZONTAL
}

fun Context.tv(t: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
    text = t; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
    if (bold) setTypeface(null, Typeface.BOLD)
    setPadding(0, dp(8), 0, dp(8))
}

fun Context.btn(t: String, f: () -> Unit) = Button(this).apply {
    text = t; setTextColor(Color.BLACK); setBackgroundColor(Color.WHITE)
    setOnClickListener { f() }
    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
}

fun Context.edit(h: String) = EditText(this).apply {
    hint = h; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
}

fun Context.toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
