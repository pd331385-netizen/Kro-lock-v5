package com.karolock

import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** In-memory unlock state; wiped when the screen turns off. */
object Session {
    @Volatile var appUnlocked = false
    val unlocked = mutableSetOf<String>()
}

/** Everything is stored in AES-256 encrypted prefs (Android Keystore). The secret is never saved, only a salted PBKDF2 hash. */
class Prefs(ctx: Context) {
    private val sp = EncryptedSharedPreferences.create(
        ctx, "karo_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    val hasCredential get() = sp.contains("hash")
    val isPattern get() = sp.getBoolean("pattern", false)

    var bio: Boolean
        get() = sp.getBoolean("bio", true)
        set(v) { sp.edit().putBoolean("bio", v).apply() }

    var locked: Set<String>
        get() = sp.getStringSet("locked", emptySet())!!.toSet()
        set(v) { sp.edit().putStringSet("locked", v).apply() }

    fun setCredential(secret: String, pattern: Boolean) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        sp.edit().putString("salt", b64(salt)).putString("hash", b64(hash(secret, salt)))
            .putBoolean("pattern", pattern).putInt("fails", 0).putLong("until", 0).apply()
    }

    fun verify(secret: String): Boolean {
        val salt = Base64.decode(sp.getString("salt", "")!!, Base64.NO_WRAP)
        val expected = Base64.decode(sp.getString("hash", "")!!, Base64.NO_WRAP)
        return MessageDigest.isEqual(expected, hash(secret, salt))
    }

    // Brute-force protection: every 5 wrong tries => wait 30s, 60s, 90s...
    fun lockoutLeftMs() = (sp.getLong("until", 0) - System.currentTimeMillis()).coerceAtLeast(0)
    fun fail() {
        val f = sp.getInt("fails", 0) + 1
        val e = sp.edit().putInt("fails", f)
        if (f % 5 == 0) e.putLong("until", System.currentTimeMillis() + 30_000L * (f / 5))
        e.apply()
    }
    fun ok() { sp.edit().putInt("fails", 0).putLong("until", 0).apply() }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun hash(s: String, salt: ByteArray) =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(s.toCharArray(), salt, 120_000, 256)).encoded
}
