package com.karolock

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat

/** Watches which app comes to the foreground and shows the lock screen for protected apps. */
class LockService : AccessibilityService() {
    private val prefs by lazy { Prefs(this) }
    private var last = ""

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            Session.unlocked.clear(); Session.appUnlocked = false; last = ""
        }
    }

    override fun onServiceConnected() {
        ContextCompat.registerReceiver(this, screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF),
            ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui" ||
            pkg.contains("inputmethod") || pkg.contains("keyboard")) return
        if (pkg != last) {                     // left the previous app => lock it again
            Session.unlocked.retainAll(setOf(pkg)); last = pkg
        }
        if (pkg in prefs.locked && pkg !in Session.unlocked) {
            startActivity(Intent(this, LockActivity::class.java).putExtra("pkg", pkg)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
        }
    }

    override fun onInterrupt() {}
    override fun onDestroy() { unregisterReceiver(screenOff); super.onDestroy() }
}
