package com.karolock

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class LockActivity : AppCompatActivity() {
    private lateinit var prefs: Prefs
    private lateinit var target: String
    private lateinit var msg: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // Blocks screenshots and hides this screen in the recents preview
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        prefs = Prefs(this)
        target = intent.getStringExtra("pkg") ?: packageName
        val name = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(target, 0)).toString() }
                   catch (e: Exception) { "App" }

        val r = col()
        r.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_logo_fg)
            layoutParams = LinearLayout.LayoutParams(dp(96), dp(96))
        })
        r.addView(tv("Karo Lock", 24f, true))
        msg = tv(if (target == packageName) "Enter your lock" else "$name is locked")
        r.addView(msg)

        if (prefs.isPattern) {
            r.addView(PatternView(this) { p -> if (p.isNotEmpty()) tryUnlock(p) })
        } else {
            val e = edit("Password / PIN")
            r.addView(e)
            r.addView(btn("Unlock") { tryUnlock(e.text.toString()); e.text.clear() })
        }
        if (prefs.bio && canBio()) r.addView(btn("Use fingerprint") { showBio() })
        setContentView(r)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { leave() }
        })
        if (prefs.bio && canBio()) showBio()
    }

    private fun leave() {
        if (target == packageName) finishAffinity()
        else {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            finish()
        }
    }

    private fun tryUnlock(s: String) {
        val left = prefs.lockoutLeftMs()
        if (left > 0) { msg.text = "Too many attempts. Wait ${left / 1000 + 1}s"; return }
        if (prefs.verify(s)) { prefs.ok(); success() }
        else {
            prefs.fail()
            val l = prefs.lockoutLeftMs()
            msg.text = if (l > 0) "Too many attempts. Wait ${l / 1000 + 1}s" else "Wrong. Try again"
        }
    }

    private fun success() {
        if (target == packageName) Session.appUnlocked = true else Session.unlocked.add(target)
        finish()
    }

    private fun canBio() = BiometricManager.from(this)
        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

    private fun showBio() {
        val p = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { prefs.ok(); success() }
            })
        p.authenticate(BiometricPrompt.PromptInfo.Builder()
            .setTitle("Karo Lock").setSubtitle("Unlock with fingerprint")
            .setNegativeButtonText("Use password / pattern")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).build())
    }
}
