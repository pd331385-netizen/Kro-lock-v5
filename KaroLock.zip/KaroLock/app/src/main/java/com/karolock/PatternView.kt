package com.karolock

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/** 3x3 pattern pad. onDone gets "0124"-style string, or "" if fewer than 4 dots. */
class PatternView(c: Context, private val onDone: (String) -> Unit) : View(c) {
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; strokeWidth = 10f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val path = mutableListOf<Int>()
    private var x = 0f; private var y = 0f; private var dragging = false

    private fun cx(i: Int) = width / 6f + (i % 3) * width / 3f
    private fun cy(i: Int) = height / 6f + (i / 3) * height / 3f

    override fun onMeasure(w: Int, h: Int) {
        val s = MeasureSpec.getSize(w); setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        for (i in 0..8) c.drawCircle(cx(i), cy(i), if (i in path) 22f else 12f, dot)
        for (k in 1 until path.size) c.drawLine(cx(path[k - 1]), cy(path[k - 1]), cx(path[k]), cy(path[k]), line)
        if (dragging && path.isNotEmpty()) c.drawLine(cx(path.last()), cy(path.last()), x, y, line)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        x = e.x; y = e.y
        if (e.action == MotionEvent.ACTION_DOWN) { path.clear(); dragging = true }
        if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) {
            dragging = false
            val p = if (path.size >= 4) path.joinToString("") else ""
            path.clear(); invalidate(); onDone(p); return true
        }
        for (i in 0..8) if (i !in path && hypot(x - cx(i), y - cy(i)) < width / 8f) path.add(i)
        invalidate(); return true
    }
}
