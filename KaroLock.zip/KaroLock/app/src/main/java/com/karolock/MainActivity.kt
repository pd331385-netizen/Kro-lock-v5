package com.karolock

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: Prefs

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        prefs = Prefs(this)
    }

    override fun onResume() {
        super.onResume()
        when {
            !prefs.hasCredential -> showSetup()
            !Session.appUnlocked -> startActivity(Intent(this, LockActivity::class.java).putExtra("pkg", packageName))
            else -> showApps()
        }
    }

    private fun showSetup() {
        val r = col()
        r.addView(tv("Karo Lock", 28f, true))
        r.addView(tv("Choose how to lock your apps"))
        r.addView(btn("Password / PIN") { showPassword() })
        r.addView(btn("Pattern") { showPattern() })
        setContentView(r)
    }

    private fun showPassword() {
        val r = col(); val a = edit("New password / PIN"); val c = edit("Confirm")
        r.addView(tv("Create password", 22f, true)); r.addView(a); r.addView(c)
        r.addView(btn("Save") {
            val s = a.text.toString()
            if (s.length < 4) toast("Minimum 4 characters")
            else if (s != c.text.toString()) toast("Does not match")
            else { prefs.setCredential(s, false); Session.appUnlocked = true; showApps() }
        })
        setContentView(r)
    }

    private fun showPattern() {
        var first: String? = null
        val r = col(); val m = tv("Draw a pattern (min 4 dots)", 18f)
        r.addView(m)
        r.addView(PatternView(this) { p ->
            if (p.isEmpty()) toast("Connect at least 4 dots")
            else if (first == null) { first = p; m.text = "Draw again to confirm" }
            else if (p == first) { prefs.setCredential(p, true); Session.appUnlocked = true; showApps() }
            else { first = null; m.text = "Did not match. Start again" }
        })
        setContentView(r)
    }

    private fun showApps() {
        val r = col().apply { setPadding(dp(20), dp(24), dp(20), dp(24)) }
        r.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_logo_fg)
            layoutParams = LinearLayout.LayoutParams(dp(80), dp(80))
        })
        r.addView(tv("Karo Lock", 24f, true))

        val on = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        if (!on) {
            r.addView(tv("Step 1: turn on the Karo Lock service so apps can be locked"))
            r.addView(btn("Enable service") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        }
        r.addView(Switch(this).apply {
            text = "Fingerprint unlock"; setTextColor(Color.WHITE); isChecked = prefs.bio
            setOnCheckedChangeListener { _, v -> prefs.bio = v }
        })
        r.addView(btn("Change lock (password / pattern)") { showSetup() })
        r.addView(tv("Choose apps to lock", 18f, true))

        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        for ((pkg, label) in apps) {
            r.addView(Switch(this).apply {
                text = label; setTextColor(Color.WHITE); isChecked = pkg in prefs.locked
                setPadding(0, dp(10), 0, dp(10))
                setOnCheckedChangeListener { _, v -> prefs.locked = if (v) prefs.locked + pkg else prefs.locked - pkg }
            })
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(r) })
    }
}
